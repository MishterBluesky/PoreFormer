#if !defined(AFX_HELP_H_224B21B8_C13C_2248_BF23_124095086211__INCLUDED_)
#define AFX_HELP_H_224B21B8_C13C_2248_BF23_124095086211__INCLUDED_
#include <string>

class help
{
public:

	help(int version, std::string exe);
	 ~help();
};

#endif
