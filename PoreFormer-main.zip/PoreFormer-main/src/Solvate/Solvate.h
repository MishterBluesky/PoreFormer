#if !defined(AFX_Solvate_H_SF4A21B8_C13C_1223_BF23_124095086234__INCLUDED_)
#define AFX_Solvate_H_SF4A21B8_C13C_1223_BF23_124095086234__INCLUDED_

#include "Def.h"
class Solvate
{
public:
    
	Solvate(Argument *pArg);
	 ~Solvate();
    


public:
    
       // inline const std::string GetFileName()    const {return m_FileName;}




private:

   // std::string m_FileName;

};

#endif
