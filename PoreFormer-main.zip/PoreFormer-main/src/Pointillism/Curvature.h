#if !defined(AFX_Curvature_H_524B21B8_C13C_2248_BF23_124095086233__INCLUDED_)
#define AFX_Curvature_H_524B21B8_C13C_2248_BF23_124095086233__INCLUDED_

#include "SimDef.h"
#include "vertex.h"
#include "triangle.h"
#include "links.h"

class Curvature
{
public:
    
	Curvature(vertex *p);
	 ~Curvature();




       // inline const int GetTriID()                const  {return m_ID;}

    


public:
    



private:
    vertex * m_pVertex;


private:
    Tensor2 Householder(Vec3D N);

    
    
    
//vertex *m_V1;




    





};


#endif
