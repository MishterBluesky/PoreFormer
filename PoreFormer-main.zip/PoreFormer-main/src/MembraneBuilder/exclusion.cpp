

#include "exclusion.h"


exclusion::exclusion(int id,int vid, double R)
{
    m_ID=id;
    m_R = R;
    m_PointID = vid;

}
exclusion::~exclusion()
{
    
}




